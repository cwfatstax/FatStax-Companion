function serverStatus() {
    var url = document.getElementById('serverURL').value;
    var interval = document.getElementById('statusInterval').value * 60000;
    setInterval(function () {
        function checkTime(i) {
            return (i < 10) ? "0" + i : i;
        }

        var response = new XMLHttpRequest;
        var today = new Date(),
            h = checkTime(today.getHours()),
            m = checkTime(today.getMinutes());
        response.open('GET', url);
        response.onload = function () {
            console.log('Status: ', response.status + ' @ ' + h + ':' + m);
            if (response.status === 200) {
                document.body.style.backgroundColor = 'green';
            } else {
                document.body.style.backgroundColor = 'red';
            }
        };
        response.send();
}, interval);
}